<script>
	import { open } from '@tauri-apps/api/dialog'
	import { readTextFile } from  '@tauri-apps/api/fs'
	import Page2 from './Page2.svelte'
	import Page3 from './Page3.svelte'
	import Page4 from './Page4.svelte'
	import Page5 from './Page5.svelte'
	
	let page = 0
	let fileNames = ["File", "File"]

	const nextPage = () => {
		readGPC()
		page++
	}
	const previousPage = () => {
		page--
	}

	const openFile = async (_fileNo) => {
		try {
			const selectedFileName = await open({
				multiple: false,
				title: "Open GPC File",
				filters: [{
					name: 'GPC',
					extensions: ['gpc']
				}]
			})
			if(selectedFileName !== null)
				fileNames[_fileNo] = selectedFileName
		} catch (error) {
			console.log(error)
		}
	}

	const readGPC = async () => {
        try {
            const result = await readTextFile(fileNames[0])
            let gpcText = result
            console.log(gpcText)
            return true
        } catch (err) {
            console.log(err)
            return false
        }
    }

	const goToPage = (pageNo) => {
		page = pageNo
	}


</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
{#if page == 0}
	<main>
		<h1 class="glow pointer">GSIM/MoviolaW Comparison Tool</h1>
		<h2 class="pointer">Please select .GPC files</h2>
		<p>Space in the filename will cause error</p>
		<div style="float:center;">
			<button type="button" id="gpc1" class="choose" on:click={() => {openFile(0)}} value="Open File 1">OpenFile1</button>
			<button type="button" id="gpc2" class="choose" on:click={() => {openFile(1)}} value="Open File 2">OpenFile2</button>
		</div><br><br>

		<form>
			<p><label for="name">Designer's name:</label></p>
			<input type="text" id="name" name="name">
			
		</form><br>

		<form>
			<p><label for="name">Checker's name:</label></p>
			<input type="text" id="name" name="name"><br>
			<input type="submit" value="Submit">
		</form><br><br>
		
		<div class="footer"><div style="float:right;">
			<br><button type="button" id="nextBtn" class="next" on:click={() => {nextPage()}}>Next &raquo</button>
		</div>
			<h6>Developed by Data Aunz</h6>
		</div>
	</main>
{/if}
	
{#if page == 1}
	<div class="navbar" style="font-family: monospace;">
		<a href="#" on:click={() => {goToPage(0)}}><i class="fa fa-fw fa-home"></i> Home</a> 
		<a class="active" href="#"><i class="fa fa-fw fa-exchange"></i> Updated Items</a> 
		<a href="#" on:click={() => {goToPage(2)}}><i class="fa fa-fw fa-list"></i> Deleted Items</a> 
		<a href="#" on:click={() => {goToPage(3)}}><i class="fa fa-fw fa-signal"></i> Inserted Items</a>
		<a href="#" on:click={() => {goToPage(4)}}><i class="fa fa-fw fa-road"></i> Show All</a>
		<a href="#" on:click={() => {print()}}><i class="fa fa-fw fa-print"></i> Print</a>
  	</div>
	<Page2/>
	<main2>
		<br><div class="footer"><div style="float:right;">
			<br><button type="button" id="prevBtn" class="previous" on:click={() => {previousPage()}}>&laquo; Previous</button>
			<button type="button" id="nextBtn" class="next" on:click={() => {nextPage()}}>Next &raquo</button>
		</div>
			<h6>Data Aunz</h6>
		</div>
	</main2>
{/if}

{#if page == 2}
	<div class="navbar" style="font-family: monospace;">
		<a href="#" on:click={() => {goToPage(0)}}><i class="fa fa-fw fa-home"></i> Home</a> 
		<a href="#" on:click={() => {goToPage(1)}}><i class="fa fa-fw fa-exchange"></i> Updated Items</a> 
		<a class="active" href="#"><i class="fa fa-fw fa-list"></i> Deleted Items</a> 
		<a href="#" on:click={() => {goToPage(3)}}><i class="fa fa-fw fa-signal"></i> Inserted Items</a>
		<a href="#" on:click={() => {goToPage(4)}}><i class="fa fa-fw fa-road"></i> Show All</a>
		<a href="#" on:click={() => {print()}}><i class="fa fa-fw fa-print"></i> Print</a>
  	</div>
	<Page3/>
	<main3>
		<br><div class="footer"><div style="float:right;">
			<br><button type="button" id="prevBtn" class="previous" on:click={() => {previousPage()}}>&laquo; Previous</button>
			<button type="button" id="nextBtn" class="next" on:click={() => {nextPage()}}>Next &raquo</button>
		</div>
			<h6>Data Aunz</h6>
		</div>
	</main3>		
{/if}

{#if page == 3}
	<div class="navbar" style="font-family: monospace;">
		<a href="#" on:click={() => {goToPage(0)}}><i class="fa fa-fw fa-home"></i> Home</a> 
		<a href="#" on:click={() => {goToPage(1)}}><i class="fa fa-fw fa-exchange"></i> Updated Items</a> 
		<a href="#" on:click={() => {goToPage(2)}}><i class="fa fa-fw fa-list"></i> Deleted Items</a> 
		<a class="active" href="#"><i class="fa fa-fw fa-signal"></i> Inserted Items</a>
		<a href="#" on:click={() => {goToPage(4)}}><i class="fa fa-fw fa-road"></i> Show All</a>
		<a href="#" on:click={() => {print()}}><i class="fa fa-fw fa-print"></i> Print</a>
	</div>
	<Page4/>
	<main4>
		<br><div class="footer"><div style="float:right;">
			<br><button type="button" id="prevBtn" class="previous" on:click={() => {previousPage()}}>&laquo; Previous</button>
			<button type="button" id="nextBtn" class="next" on:click={() => {nextPage()}}>Next &raquo</button>
		</div>
			<h6>Developed by Data Aunz</h6>
		</div>
	</main4>		
{/if}

{#if page == 4}
	<div class="navbar" style="font-family: monospace;">
		<a href="#" on:click={() => {goToPage(0)}}><i class="fa fa-fw fa-home"></i> Home</a> 
		<a href="#" on:click={() => {goToPage(1)}}><i class="fa fa-fw fa-exchange"></i> Updated Items</a> 
		<a href="#" on:click={() => {goToPage(2)}}><i class="fa fa-fw fa-list"></i> Deleted Items</a> 
		<a href="#" on:click={() => {goToPage(3)}}><i class="fa fa-fw fa-signal"></i> Inserted Items</a>
		<a class="active" href="#"><i class="fa fa-fw fa-road"></i> Show All</a>
		<a href="#" on:click={() => {print()}}><i class="fa fa-fw fa-print"></i> Print</a>
	</div>
	<Page5/>
	<main5>
		<br><div class="footer"><div style="float:right;">
			<br><button type="button" id="prevBtn" class="previous" on:click={() => {previousPage()}}>&laquo; Previous</button>
			<button type="button" id="nextBtn" class="next" on:click={() => {nextPage()}}>Next &raquo</button>
		</div>
			<h6>Data Aunz</h6>
		</div>
	</main5>		
{/if}


<style global>
	main {
		padding: 1em;
		max-width: 240px;
		margin: 0 Auto;
		height: 100%;
		text-align: center;
		font-family: monospace;
	}
	main2{
        padding: 1em;
		max-width: 240px;
		margin: 0 Auto;
		height: 100%;
		font-family: monospace;
    }


	h1 {
		color: #80489C;
		
		font-size: 4em;
		font-weight: bold;
		text-align: center;
		font-family: monospace;
	}
	
	h2 {
		color: #379237;
		text-transform: full-width;
		font-size: large;
		font-family: monospace;
		font-weight: bolder;
		text-align: center;
	}
	h6 {
		color: white;
		text-transform: full-width;
		font-size: xx-small;
		font-family: monospace;
		font-weight: bolder;
		text-align: center;
	}

	p {
		color: #379237;
		text-transform: full-width;
		font-size: medium;
		font-family: monospace;
		font-weight: auto;
		text-align: center;
	}
	

	@media (min-width: 540px) {
		main {
			max-width: none;
		}
	}
	.choose {
		background-color: #006666;
		color: white;
	}
	.next {
		background-color: #04AA6D;
		color: white;
	}
	.previous {
		background-color: #EEEEEE;
		color: black;
	}


	button {
		background-color: #04AA6D;
		color: #ffffff;
		border: none;
		padding: 10px 20px;
		font-size: medium;
		font-family: monospace;
		cursor: pointer;
	}
	button:hover {
		opacity: 0.8;
	}
	.glow {
		font-size: 70px;
		color: #fff;
		text-align: center;
		animation: glow 1s ease-in-out infinite alternate;
	}

	@-webkit-keyframes glow {
  		from {
    		text-shadow: 0 0 10px #fff, 0 0 20px #fff, 0 0 30px #7BA5BD, 0 0 40px #7BA5BD, 0 0 50px #7BA5BD, 0 0 60px #7BA5BD, 0 0 70px #7BA5BD;
 		}
  
  		to {
    		text-shadow: 0 0 20px #fff, 0 0 30px #0794A7, 0 0 40px #0794A7, 0 0 50px #0794A7, 0 0 60px #0794A7, 0 0 70px #0794A7, 0 0 80px #0794A7;
  		}
	}	

	.footer {
		position: fixed;
		left: 0;
		bottom: 0;
		width: 100%;
		background-color: #0794A7 ;
		color: white;
		text-align: center;
	}

	body {font-family: Arial, Helvetica, sans-serif;}

	.navbar {
		position: fixed;
		left: 0;
		top: 0;
		width: 100%;
		background-color: #0794A7;
		overflow: auto;
	}

	.navbar a {
		float: left;
		padding: 12px;
		color: white;
		text-decoration: none;
		font-size: 100%;
	}

	.navbar a:hover {
		background-color: rgb(0, 190, 220);
	}

	.active {
		background-color: rgb(0, 85, 124);
	}

	@media screen and (max-width: 500px) {
		.navbar a {
			float: none;
			display: block;
		}
	}
	.pointer {cursor: pointer;}
</style>