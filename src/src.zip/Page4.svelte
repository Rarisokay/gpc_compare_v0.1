<script>
    const nextPage = () => {
		readGPC()
		page++
	}
	const previousPage = () => {
		page--
	}
</script>

<main4>
    <h2 class="pointer">Inserted Items</h2>
    <p class="pointer">Report insert colour = <strong style="color:red">Red</strong></p>

    <input type="text" id="myInput" on:keyup={() => {myFunction()}} placeholder="Search for names.." title="Type in a name">  
    <table id="myTable">
      <tr class="header">
        <th colspan="3">2nd GPC file</th>
      </tr>
      <tr class="header">
        <th>Name</th>
        <th>Bit</th>
        <th>Mnemonic</th>
      </tr>
      <tr class="deleted">
        <td rowspan="2">Track1</td>
        <td>USR</td>
        <td>W1-1</td>
      </tr>
      <tr>

        <td>USR</td>
        <td>W1-3ECR</td>
      </tr>
      <tr>
        <td>PT.103</td>
        <td>NKR</td>
        <td>W1-101NKR</td>
      </tr>
      <tr>
        <td>SIG.2</td>
        <td>ECR</td>
        <td>W1-2ECR</td>
      </tr>
    </table>
  
</main4>







<style>
    h2 {
  color: #80489C;
  font-weight: bold;
      font-size: 250%;
  text-align: center;
  font-family: monospace;
  }
  p {
    color: #000000;
    font-size: large;
    font-weight: 100;
  }

  Main4 {
    padding: 1em;
    max-width: 240px;
    margin: 0 Auto;
    height: 100%;
    font-family: monospace;
  }
  @media (min-width: 640px) {
    main {
      max-width: none;
    }
  }
  button {
		background-color: #04AA6D;
		color: #ffffff;
		border: none;
		padding: 10px 20px;
		font-family: monospace;
		cursor: pointer;  
	}
	button:hover {
		opacity: 0.8;
	}

  * {
      box-sizing: border-box;
  }

  .row {
      margin-left:-5px;
      margin-right:-5px;
  }

  .column {
      float: left;
      width: 50%;
      padding: 5px;
  }
  .row::after {
      content: "";
      clear: both;
      display: table;
  }
  table{
      border-collapse: collapse;
      border-spacing: 0;
      width: 100%;
      border: 1px solid #ddd;
  }

  th, td{
      text-align: left;
      padding: 16px;
  }


  section {
		width: 300px;
	}
  .content {
		background-color: #f4f4f4;
		padding: 0.5em;
	}

  #myInput {
    background-position: 10px 10px;
    background-repeat: no-repeat;
    width: 100%;
    font-size: 16px;
    padding: 12px 20px 12px 40px;
    border: 1px solid #ddd;
    margin-bottom: 12px;
  }

  #myTable {
    border-collapse: collapse;
    width: 100%;
    border: 1px solid #ddd;
    font-size: large;
  }

  #myTable th, #myTable td {
    text-align: left;
    padding: 12px;
    border: 1px solid #ddd;
  }

  #myTable tr {
    border-bottom: 1px solid #ddd;
  }

  #myTable tr.header, #myTable tr:hover {
    background-color: #f1f1f1;
  }
  .pointer {cursor: pointer;}
  </style>