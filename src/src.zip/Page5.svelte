<script>
    function myFunction() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[0];
        if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            tr[i].style.display = "";
        } else {
            tr[i].style.display = "none";
        }
        }       
    }
    }
    
    function mFunction() {
        var x = document.getElementById("myDIV");
        if (x.innerHTML === "Hello") {
            x.innerHTML = "Swapped text!";
        } else {
            x.innerHTML = "Hello";
        }
    }
    
</script>

<meta name="viewport" content="width=device-width, initial-scale=1">

<main5>
    <h2 class="pointer">Show All</h2>
    <p>Search for left table</p>
      <input type="text" id="myInput" on:keyup={() => {myFunction()}} placeholder="Search for names.." title="Type in a name">
      
      <div class="row">
        <div class="column">
          <table id="myTable">
            <tr class="header">
              <th colspan="3">1st GPC file</th>
            </tr>
            <tr class="header">
              <th>Name</th>
              <th>Bit</th>
              <th>Mnemonic</th>
            </tr>
            <tr class="deleted">
              <td rowspan="2">Track1</td>
              <td>USR</td>
              <td>W1-1</td>
            </tr>
            <tr>

              <td>USR</td>
              <td>W1-3ECR</td>
            </tr>
            <tr>
              <td>PT.101</td>
              <td>NKR</td>
              <td>W1-101NKR</td>
            </tr>
            <tr>
              <td>SIG.2</td>
              <td>ECR</td>
              <td>W1-2ECR</td>
            </tr>
          </table>
        </div>
        <div class="column">
          <table id="myTable">
            <tr class="header">
              <th colspan="3">2nd GPC file</th>
            </tr>
            <tr class="header">
              <th>Name</th>
              <th>Bit</th>
              <th>Mnemonic</th>
            </tr>
            <tr class="inserted">
              <td rowspan="2">Track1</td>
              <td>USR</td>
              <td>W1-1(A-B)</td>
            </tr>
            <tr>

              <td>USR</td>
              <td>W1-3ECR</td>
            </tr>
            <tr>
              <td>PT.101</td>
              <td>NKR</td>
              <td>W1-101NKR</td>
            </tr>
            <tr>
              <td>SIG.2</td>
              <td>ECR</td>
              <td>W1-2ECR</td>
            </tr>
          </table>
        </div>
      </div>

    <button on:click={() => {mFunction()}}>Click Me</button>

    <div id="myDIV">Hello</div>
</main5>






<style>
  h2 {
  color: #80489C;
  font-weight: bold;
      font-size: 250%;
  text-align: center;
  font-family: monospace;
  }
  h3 {
    color: #000000;
    text-transform: uppercase;
    font-size: 4em;
    font-weight: 100;
  }

  Main5 {
    padding: 1em;
    max-width: 240px;
    margin: 0 Auto;
    height: 100%;
    font-family: monospace;
  }

  @media (min-width: 640px) {
    main {
      max-width: none;
    }
  }
  button {
		background-color: #04AA6D;
		color: #ffffff;
		border: none;
		padding: 10px 20px;
		font-family: monospace;
		cursor: pointer;  
	}
	button:hover {
		opacity: 0.8;
	}


  * {
  box-sizing: border-box;
}
  .row {
        margin-left:-5px;
        margin-right:-5px;
    }

    .column {
        float: left;
        width: 50%;
        padding: 5px;
    }
    .row::after {
        content: "";
        clear: both;
        display: table;
    }
#myInput {
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: large;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
  border: 1px solid #ddd;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
.pointer {cursor: pointer;}
</style>